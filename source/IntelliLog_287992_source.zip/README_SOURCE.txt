IntelliLog - RICE 2026 - Paper #287992 - source package (D2)

paper.docx                  Word source, taken from origin/main RICE2026_Paper287992_IntelliLog_CameraReady.docx
                            with two edits listed in CHANGES.md (footer "PUBLIC" text removed; Table II
                            cross-reference removed from the contributions bullet).
fig2_bar_chart_raster.png   Figure 2 raster image (965x688 px, embedded at 2.95 x 2.1 in = ~327 dpi).
                            Fig. 1 is a native Word vector drawing inside paper.docx.

Open paper.docx in Microsoft Word (US Letter, IEEE two-column). Do not rebuild from any other copy.
This package does NOT contain a PDF. See camera_ready/README.md.
