IntelliLog - RICE 2026 - Paper #287992 - source package (candidate, v2)

paper.docx                 Word source (v2): origin/main file + edits E1-E7 in CHANGES.md
fig2_bar_chart_raster.png  Figure 2 raster (965x688 px, ~327 dpi). Vector export still requested from authors.
Fig. 1 is a native Word vector drawing inside paper.docx.

This package contains NO PDF. The camera-ready PDF must be exported from paper.docx in Microsoft Word,
then validated by IEEE PDF eXpress (Conference ID 71332X). Not yet validated.
